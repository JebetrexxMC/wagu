========================================================================
ADVANCED TACTICAL COMPASS - README
========================================================================

Thank you for downloading the Advanced Tactical Compass mod! This is a 
sleek, lightweight, and performance-optimized tactical compass interface for 
GTA San Andreas PC, built on the fast MoonLoader framework.

------------------------------------------------------------------------
1. PLATFORM & COMPATIBILITY
------------------------------------------------------------------------
- Game: Grand Theft Auto: San Andreas (PC)-(SA-MP)
- Framework: MoonLoader v0.26 or higher

------------------------------------------------------------------------
2. KEY FEATURES
------------------------------------------------------------------------
- Multiple Display Modes: Seamlessly cycle through various styles including Mini (no border), Mini (with border), Full (with border), Full (no border), or completely hidden.

- Adjustable Screen Layouts: Easily toggle the position of the compass between the top and bottom of your screen to perfectly fit your custom UI setup.

- Dynamic Waypoint Tracking: Automatically tracks your target/waypoint blip, displaying real-time distance in meters and precise directional indicators.

- Smooth Animations & Edge Fading: Features advanced gradient edge-blur rendering where ticks, numbers, and custom markers smoothly fade out near the boundaries.

- Responsive Resolution Auto-Scaling: Universal responsive layout optimized for a 1920x1080 canvas base that dynamically auto-calculates dimensions upon any resolution changes.

- Persistent Configuration: Automatically saves your active display mode and layout preferences to an INI configuration file so you don't have to reconfigure on restart.

------------------------------------------------------------------------
3. CONTROLS & OPERATION
------------------------------------------------------------------------
- Cycle Display Modes: ALT + J

- Toggle Screen Layout (Top/Bottom): ALT + H

------------------------------------------------------------------------
4. REQUIREMENTS
------------------------------------------------------------------------
Make sure your game directory has the following installed:
- GTA San Andreas v1.0 US (gta_sa.exe)
- An ASI Loader installed (e.g., Silent's ASI Loader or CLEO ASI Loader)
- MoonLoader (v0.26+)

------------------------------------------------------------------------
5. INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------
1. Locate the downloaded file: "Advanced Tactical Compass"
2. Drag and drop it directly into your game's "moonloader" folder.
   (Example path:....\GTA San Andreas\moonloader\Advanced Tactical Compass.luac)
3. Start your game. The script will initialize automatically.

------------------------------------------------------------------------
6. CREDITS
------------------------------------------------------------------------
- Developed & Optimized by: zConnor.i22 x dmitriyewich AKA Opк (for the idea)

========================================================================
Have fun navigating!
========================================================================
Support my work: https://ko-fi.com/zconnori22

I want to take a moment to express my deepest gratitude to everyone who has supported me lately.
Whether you’ve downloaded my mods, shared them with your friends, or contributed a donation, thank you!
The GTA SA community has always been special to me, and being able to contribute to it is an honor. Your support gives me the energy to keep working on new ideas and improvements. Let’s keep this game going for many more years to come <3