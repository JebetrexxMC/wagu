script_name("training-autologin")
script_description("TRAINING-SANDBOX autologin")
script_authors("xWivar", "1NS")
script_dependencies('lib.samp.events')
script_url("https://forum.training-server.com/d/17909-lua-autologin-v1")
script_version_number(4)
script_version("4.2.2")
-- Require CLEO 4.0+, SAMPFUNCS 5.4.0+, Moonloader 0.26+ (lib SAMP.Lua)
-- editor options: tabsize 3, Windows (CR LF), encoding Windows-1251

local ev = require 'lib.samp.events'
local ini = require 'inicfg'
local cfg = ini.load({Hashtable = {}}, "training-autologin")
local ffi = require("ffi")
ffi.cdef[[
int __stdcall GetVolumeInformationA(
    const char* lpRootPathName,
    char* lpVolumeNameBuffer,
    uint32_t nVolumeNameSize,
    uint32_t* lpVolumeSerialNumber,
    uint32_t* lpMaximumComponentLength,
    uint32_t* lpFileSystemFlags,
    char* lpFileSystemNameBuffer,
    uint32_t nFileSystemNameSize
);
]]
local eax = nil
local ebx = ffi.new("unsigned long[1]", 0)
ffi.C.GetVolumeInformationA(eax, eax, 0, ebx, eax, eax, eax, 0)
local ecx = ebx[0]
-- Flag to intercept the input dialog
local hookdialogpassw = false
local autologinfailed = false
-- Script options (Change them for your own needs)
local skiprulesdialog = true
local skiplang = true
local defaultlangrus = false

function main()
   sampRegisterChatCommand("newpass", function(arg)
      sampSendChat("/newpass "..arg)
      if 6 <= #arg and #arg <= 24 then 
         local _, id = sampGetPlayerIdByCharHandle(playerPed)      
         local nickname = sampGetPlayerNickname(id)
         cfg.Hashtable[nickname] = toHash(("%s%s"):format(tostring(arg), ecx))
         ini.save(cfg, "training-autologin") 
      end
   end)
end

function ev.onInitGame(playerId, hostName, settings, vehicleModels, unknown)
   local configfile = io.open(getGameDirectory()..'/moonloader/config/training-autologin.ini', "r")
   if configfile == nil then
      print("restore broken configfile")   
      configfile = io.open(getGameDirectory()..'/moonloader/config/training-autologin.ini', "w")
      configfile:write("")
      configfile:close()
      autologinfailed = true
   end
end

function ev.onPlayerJoin(playerid, color, isNpc, nickname)
   local _, id = sampGetPlayerIdByCharHandle(playerPed)
   if playerid == id then 
      hookdialogpassw = false 
   end
end

function ev.onShowDialog(dialogId, style, title, button1, button2, text)
   if dialogId == 32700 then
      -- Auto select Language
      if skiplang then
         if title:find('Select Language') then
            if defaultlangrus then
               sampSendDialogResponse(32700, 1, 1, "Russian")
            else
               sampSendDialogResponse(32700, 1, 0, "English")
            end
            sampCloseCurrentDialogWithButton(0)
         end
      end
      
      -- Skip rules dialog
      if skiprulesdialog then 
         if text:find('1. ����� �������') and style == 0 and button1 == "��������" then
            sampSendDialogResponse(32700, 1, nil)
            sampCloseCurrentDialogWithButton(1)
         end
         if text:find('1. Main') and style == 0 and button1 == "��������" then
            sampSendDialogResponse(32700, 1, nil)
            sampCloseCurrentDialogWithButton(1)
         end
      end
      
      -- Hook login dialog
      if text:find('�� ������������ �') or text:find('You have connected')
      and button1:find('>>>') then
         local _, id = sampGetPlayerIdByCharHandle(playerPed)      
         local nickname = sampGetPlayerNickname(id)
         hookdialogpassw = true
         if not autologinfailed then
            if cfg.Hashtable[nickname] ~= nil then
               local hash = fromHash(cfg.Hashtable[nickname])
               local val = hash:gsub(tostring(ecx),"")
               sampSendDialogResponse(dialogId, 1, nil, val)
               return false
            end
         end
      end
      
      if text:find('��� ������ ����������� �������') then
         hookdialogpassw = false
         autologinfailed = true
      end
   end
end

function ev.onSendDialogResponse(dialogId, button, listboxId, input)
   -- Hook login dialog if success login
   if dialogId == 32700 then
      local _, id = sampGetPlayerIdByCharHandle(playerPed)
      local nickname = sampGetPlayerNickname(id)
      
      if hookdialogpassw and button == 1 then    
         if cfg.Hashtable[nickname] == nil then
            hookdialogpassw = false
            cfg.Hashtable[nickname] = toHash(("%s%s"):format(input, ecx))
            ini.save(cfg, "training-autologin")   
            print("no nickname")
         else
            if autologinfailed then
               hookdialogpassw = false
               cfg.Hashtable[nickname] = toHash(("%s%s"):format(input, ecx))
               ini.save(cfg, "training-autologin") 
               print("autologin failed")
            end
         end
      end

   end
end


function ev.onServerMessage(color, text)
   local _, id = sampGetPlayerIdByCharHandle(playerPed)
   local nickname = sampGetPlayerNickname(id)
         
   -- if text:find("������ ������� ���������������")
   -- or text:find("This account is registered") then
   -- end
   
   if text:find("������� ������ ������! .+1/3") or text:find("Incorrect password! .+1/3") and color == -872414977 then
      -- hookdialogpassw = true
      autologinfailed = true
      cfg.Hashtable[nickname] = nil
   end
   
   if text:find("You need to log in to begin reducing your ban time") then
      autologinfailed = true
   end
end

function toHash(data)
   local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
   return ((data:gsub('.', function(x) 
      local r,b='',x:byte()
      for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
      return r;
   end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
      if (#x < 6) then return '' end
      local c=0
      for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
      return b:sub(c+1,c+1)
   end)..({ '', '==', '=' })[#data%3+1])
end
 
function fromHash(data)
   local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
   data = string.gsub(data, '[^'..b..'=]', '')
   return (data:gsub('.', function(x)
      if (x == '=') then return '' end
      local r,f='',(b:find(x)-1)
      for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
      return r;
   end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
      if (#x ~= 8) then return '' end
      local c=0
      for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
      return string.char(c)
   end))
end