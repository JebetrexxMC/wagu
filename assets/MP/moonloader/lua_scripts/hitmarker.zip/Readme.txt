¡Apoya mis mods para GTA San Andreas! https://ko-fi.com/fausto200

¡Hola a todos! Soy Fausto, creador de scripts, interfaces y herramientas personalizadas para mejorar la experiencia en GTA San Andreas y SA-MP (como hitmarkers dinámicos, HUDs flotantes y sistemas de inmersión).

Todo el contenido que desarrollo es y seguirá siendo gratuito para la comunidad. Sin embargo, desarrollar, depurar y adaptar estos mods requiere horas de trabajo y pruebas técnicas.

Si te gustan mis proyectos y quieres ayudarme a seguir dedicando tiempo a crear más contenido, scripts y mejoras visuales, puedes invitarme un café o apoyarme con una donación en Ko-fi. ¡Cualquier aporte se agradece de corazón y me motiva a seguir adelante!

------------------------------------------------
Support my GTA San Andreas Mods! https://ko-fi.com/fausto200

Hi everyone! I'm Fausto, a developer creating custom scripts, UI elements, and immersion tools for GTA San Andreas and SA-MP (such as dynamic hitmarkers, custom HUDs, and tailored gameplay systems).

All the content I develop is and will remain free for the community. However, coding, debugging, and testing these mods takes hours of dedicated work and technical effort.

If you enjoy my projects and want to help me keep spending time on creating more mods, scripts, and visual enhancements, you can buy me a coffee or support me with a donation on Ko-fi. Every bit of support is deeply appreciated and keeps me going!