# CamFX (CameraFX 2.4)

Camera FOV effects for GTA San Andreas on Android, as an AML mod. Part of the TYFMC mods (MP, MLG, CamFX).
Based on the original SACamFX CLEO script (sprint and fall zoom); this native version adds parachute,
vehicle and weapon zoom and its own settings tab.

## Install

1. Needs AML (AndroidModLoader) and SAUtils.
2. Copy `bin/libCameraFX32.so` (32-bit game) or `bin/libCameraFX64.so` (64-bit game) into the AML mods folder.
3. Start the game. Settings are in Settings > CameraFX.

| What | Where |
|---|---|
| Settings | `Android/data/com.rockstargames.gtasa/files/TYFMC/TYFMC.CAMFX.ini` |
| Data (diagnostic.log) | `Android/data/com.rockstargames.gtasa/files/TYFMC/CamFX/` |

An older `configs/CameraFX.ini` and `files/CameraFX` folder are moved there on the first start.

## Effects

- Sprint zoom: FOV widens while sprinting (speed threshold, zoom-out / zoom-in time).
- Fall zoom: FOV widens during a long fall.
- Parachute, vehicle (follows speed) and weapon (assault rifles / rifles while aiming) zoom.
- From the original SACamFX script (2.1): Change FOV When Falling (`ChangeFovWhenFall`),
  Fall Zoom Only When Sky Diving (`ParaOnly`, only while the FALL_skyDive pose plays) and
  Drunk Effect When Falling (`DrunkEffect`, the screen wobble rises while falling and goes away on landing).
- Smooth blend transitions, 8 languages.
- Car Cam FX (2.3, off until switched on): the CarCamera mod by Metalogic, built in.
- Intermezzo Cam FX (2.3, off until switched on): the Intermezzo Camera mod by cheeseburger, built in.

## Changes in 2.4

- Car Cam FX: the camera no longer resets to normal while the car is still at max speed. Letting go of the
  nitro button at top speed (nitro speed -> normal max speed) or lifting off the gas at speed was taken as
  braking: the Braking Zoom pulled the FOV / distance in and the Acceleration Zoom dropped at once.
  - Braking Zoom only reacts to a real brake (a slowdown stronger than nitro ending / coasting gives).
  - The speed view (FOV 72 + 28 x speed, distance 5.1 + 1.3 x speed) rises with the speed and comes down
    slowly, following the car's real slowdown; on a real brake it comes back faster.
  - The Acceleration Zoom builds fast and fades slowly, so releasing nitro / gas is a smooth glide.
  - A short gap without the follow camera (a few frames) no longer reads as a sudden stop.

## Changes in 2.3

- New: **Car Cam FX** toggle in the CameraFX tab (off by default). It is the CarCamera v2.7 mod by Metalogic
  (`libCarCamera32.so`), rebuilt natively for 32 and 64-bit from its decompiled camera hook (Ghidra):
  - The camera follows the car smoothly, faster in sharp turns, or stays locked behind the car.
  - It zooms out with speed, more when accelerating and less when braking.
  - It has no jitter (spring movement), goes in to the game's position at walls, and leans a little in turns.
  - Its options are in the menu too: Acceleration / Braking Zoom with distance and FOV strength,
    Faster When Turning, (Fast) Turn Follow Response and Lock To Vehicle, with the original defaults.
  - While it is on, the Vehicle FOV effect stays out of its way.
  - Don't install the separate libCarCamera32.so at the same time.
- New: **Intermezzo Cam FX** toggle (off by default). It is the Intermezzo Camera for Mobile mod by cheeseburger,
  rebuilt natively from its description: short GTA IV-style camera angles when you carjack, climb or fall.
  - Each one has a chance in the menu (defaults 50 / 35 / 75 %, like the original ini).
  - It needs no CLEO and no IniFiles, and it never runs while the player control is off.
- Fix: the settings were not kept after leaving or restarting the game. Each menu item was made before its
  saved value was loaded, so the menu always showed the defaults again. AML's Config also saved through a
  relative path (`configs/../files/...`) that does not work on every AML setup. Now:
  - The saved value is loaded first.
  - CameraFX also writes `files/TYFMC/TYFMC.CAMFX.ini` itself with the full path on every change
    (safe write: tmp file, fsync, rename).
  - The file path and the result are in `diagnostic.log`.
- `original/` now also has the CarCamera and Intermezzo Camera files (reference only).

## Changes in 2.2

- Fix: the FOOT (sprint) button showed over the ACCELERATOR button when getting into a vehicle. CameraFX asked
  the game every frame whether the sprint button was pressed, and that makes the touch HUD draw it - also while
  CJ was getting in (not "in a car" yet, but the HUD already shows the car buttons). It is not asked now while
  getting in, while in a vehicle, and for 1.5 s after getting out.
- Fix: getting out of a fast car, the camera started its smooth return and then the on-foot camera snapped it
  back. The FOV now stays held until the return has finished (the camera switch can't reset it, and if the game
  moves it anyway, the return goes on smoothly from where it should be), and the sprint zoom no longer starts
  from the speed you are thrown out with.
- GitHub Actions build (NDK r27): `.github/workflows/build.yml`.

## Changes in 2.1

- 64-bit fix: SAUtils writes a full 8-byte word back for every script output value on arm64, which
  overwrote the variable next to each 4-byte int / float. All outputs now go into 8-byte slots.
  The old SIGSEGV catch-and-skip guard is removed (it only hid the problem).
- The ini is `files/TYFMC/TYFMC.CAMFX.ini`, the data folder `files/TYFMC/CamFX`.
- The SACamFX options above, and the language choice is saved.

## Build

```
NDK=/path/to/android-ndk-r30 ./build.sh
```
Output: `bin/libCameraFX32.so` (armeabi-v7a) and `bin/libCameraFX64.so` (arm64-v8a).

## Files

- `jni/` - source (main.cpp, tyfmc.h, AML mod headers)
- `original/` - the original SACamFX CLEO script and its ini, for reference

Author: Senji. Original SACamFX CLEO script by its respective author. CarCamera by Metalogic, Intermezzo Camera by cheeseburger
(both rebuilt natively in CamFX, credit to them).
